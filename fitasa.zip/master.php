<?php include 'head.php'; ?>
</head>
<body>
<?php include 'header.php'; ?>
    <!--start container-->
    <div class="container">
        
    </div>
    <!--end container-->

<?php include 'footer.php'; ?>
</body>

</html>



